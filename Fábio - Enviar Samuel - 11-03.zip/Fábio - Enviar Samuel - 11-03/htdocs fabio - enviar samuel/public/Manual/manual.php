!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="../assets/css/main.css">
</head>
<body>
    <?php include('../../includes/main-sidebar.php'); ?> <!-- Temporario(?) -->
    <?php include('../../includes/topbar.php'); ?> 

    <div class="content">
        <h1>Manual das paginas</h1>
        <button onclick="window.location.href='maunualservicos.php'" style="padding: 10px 20px; background-color: #E50000; color: #FFFFFF; border: none; border-radius: 5px;">
            Cadastrar Serviços
        </button>
        <button onclick="window.location.href='pagina2.html'" style="padding: 10px 20px; background-color: #101820; color: #FFFFFF; border: none; border-radius: 5px;">
            Ir para Página 2
        </button>


        
    </div>
    
</body>