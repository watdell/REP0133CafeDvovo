<aside class="sidebar" id="sidebar">
    <div class="logo">
        <img src="/public/assets/images/logo.png" alt="Logo Café de Vovô">
    </div>

    <nav class="menu" id="menu">
        <ul>
            <li><a href="/index.php" class="menu-link">Home</a></li>
            <li><a href="/public/cadastro-pessoas/index.php" class="menu-link">Pessoas</a></li>
            <li><a href="/public/cadastro-produtos/index.php" class="menu-link">Produto</a></li>
            <li><a href="/public/comercial/index.php" class="menu-link">Comercial</a></li>
            <li><a href="/public/relatorios/index.php" class="menu-link">Relatório</a></li>
            
            <li><a href="/public/expedicao/index.php" class="menu-link">Expedição</a></li>
        </ul>
    </nav>

    <div class="logo">
        <img src="/public/assets/images/coffe_cup.png" alt="Copo de Café">
    </div>
</aside>